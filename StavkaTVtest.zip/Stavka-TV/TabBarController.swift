//
//  TabBarController.swift
//  StavkaTV
//
//  Created by MacBook Air on 22/11/2019.
//  Copyright © 2019 StavkaTV. All rights reserved.
//


import UIKit

class TabBarController: UITabBarController {
    let screen = UIScreen.main.bounds
    
    //==================================================//
    //=================== + Button ====================//
    //==================================================//
    lazy var plusButton: UIButton = {
        let button = UIButton(type: .custom)
        button.frame = CGRect(x: self.view.bounds.width / 2 - 25,
                              y: self.view.frame.height - self.tabBar.bounds.height, width: 50, height: 50)
        button.setImage(UIImage(named: "+"), for: .normal)
        button.imageView?.contentMode = .scaleAspectFit
        button.addTarget(nil, action: #selector(tapPlusButton), for: .touchUpInside)
        button.imageEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 12, right: 0)
        button.adjustsImageWhenHighlighted = false
        
        let btnLabel = UILabel()
        btnLabel.frame = CGRect(x: -5, y: 37, width: button.frame.width + 10, height: 10)
        btnLabel.textAlignment = .center
        btnLabel.text = "Прогноз"
        btnLabel.textColor = .lightGray
        btnLabel.font = .boldSystemFont(ofSize: 10)
        button.addSubview(btnLabel)
        return button
    }()
    
    @objc func tapPlusButton() {
        showModal()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setNeedsStatusBarAppearanceUpdate()
        
        self.view.addSubview(plusButton)
        
        //==================================================//
        //============ NavigationController #1 =============//
        //==================================================//
        let nav1 = LightNavigationController()
        nav1.tabBarItem.title = "Лента"
        nav1.tabBarItem.image = UIImage(named: "icon_main_menu_lenta")
        nav1.tabBarItem.selectedImage = UIImage(named: "icon_main_menu_lenta_selected")
        nav1.navigationBar.backgroundColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.0)
        nav1.navigationBar.setBackgroundImage(UIImage(), for: .default)
        nav1.navigationBar.shadowImage = UIImage()
        nav1.navigationBar.isTranslucent = true
        
        let feedVC = FeedVC()
        feedVC.title = "Лента"
        nav1.viewControllers = [feedVC]
        
        
        //==================================================//
        //============ NavigationController #2 =============//
        //==================================================//
        let nav2 = LightNavigationController()
        nav2.tabBarItem.title = ""
        nav2.tabBarItem.image = UIImage(named: "")

        //==================================================//
        //============ NavigationController #3 =============//
        //==================================================//
        let nav3 = LightNavigationController()
        nav3.tabBarItem.title = "Матчи"
        nav3.tabBarItem.image = UIImage(named: "icon_main_menu_places")
        nav3.tabBarItem.selectedImage = UIImage(named: "icon_main_menu_places_selected")
        nav3.navigationBar.backgroundColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.0)
        nav3.navigationBar.setBackgroundImage(UIImage(), for: .default)
        nav3.navigationBar.shadowImage = UIImage()
        nav3.navigationBar.isTranslucent = true
        
        let addPostVC = EmptyVC() // modal presentation style viewcontroller
        addPostVC.view.backgroundColor = .white
        addPostVC.title = nav3.tabBarItem.title
        nav3.viewControllers = [addPostVC]
        //==================================================//
        //============ NavigationController #4 =============//
        //==================================================//
        let nav4 = LightNavigationController()
        nav4.tabBarItem.title = "Рейтинг"
        nav4.tabBarItem.image = UIImage(named: "icon_main_menu_places")
        nav4.tabBarItem.selectedImage = UIImage(named: "icon_main_menu_places_selected")
        nav4.navigationBar.backgroundColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.0)
        nav4.navigationBar.setBackgroundImage(UIImage(), for: .default)
        nav4.navigationBar.shadowImage = UIImage()
        nav4.navigationBar.isTranslucent = true
        
        let nav4VC = EmptyVC() // modal presentation style viewcontroller
        nav4VC.view.backgroundColor = .white
        nav4VC.title = nav4.tabBarItem.title
        nav4.viewControllers = [nav4VC]
        
        //==================================================//
        //============ NavigationController #5 =============//
        //==================================================//
        let nav5 = LightNavigationController()
        nav5.tabBarItem.title = "Аккаунт"
        nav5.tabBarItem.image = UIImage(named: "icon_main_menu_places")
        nav5.tabBarItem.selectedImage = UIImage(named: "icon_main_menu_places_selected")
        nav5.navigationBar.backgroundColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.0)
        nav5.navigationBar.setBackgroundImage(UIImage(), for: .default)
        nav5.navigationBar.shadowImage = UIImage()
        nav5.navigationBar.isTranslucent = true
        
        let nav5VC = EmptyVC() // modal presentation style viewcontroller
        nav5VC.view.backgroundColor = .white
        nav5VC.title = nav5.tabBarItem.title
        nav5.viewControllers = [nav5VC]
        //==================================================//
        //==================================================//
        
        viewControllers = [nav1,nav3,nav2,nav4,nav5]
        
        tabBar.items![2].isEnabled = false
        tabBar.backgroundColor = .white
    
        tabBar.unselectedItemTintColor = .lightGray
        tabBar.barTintColor = .white
        tabBar.selectedItem?.badgeColor = .red

        tabBar.addSubview(tabIcon1)
        tabBar.addSubview(tabIcon2)
        tabBar.addSubview(tabIcon3)
        tabBar.addSubview(tabIcon4)

        UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor : UIColor.red, NSAttributedString.Key.font: UIFont.systemFont(ofSize: 10, weight: .bold)], for: .selected)
        
        NotificationCenter.default.addObserver(self, selector: #selector(showModal),
                                               name: Notification.Name(rawValue: "showModal"), object: nil)
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    
    @objc func showModal() {
        let cityPicker = ModalView(view: self.view)
        view.addSubview(cityPicker)
    }
    
    override func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        print("selected \(item.title!)")
        switch item.title! {
        case "Лента":
            animate(tabIcon1)
        case "Матчи":
            animate(tabIcon2)
        case "Рейтинг":
            animate(tabIcon3)
        case "Аккаунт":
            animate(tabIcon4)
        default:
            break
        }
        
    }
    
    func animate(_ image: UIImageView) {
        image.alpha = 0.3
        UIView.animate(withDuration: 0.3) {
            image.alpha = 1.0
        }
    }
    
    lazy var tabIcon1: UIImageView = {
        let img = UIImageView()
        img.image = UIImage(named: "tab1")
        img.frame = CGRect(x: 16, y: 4, width: 29, height: 29)
        img.contentMode = .scaleAspectFit
        return img
    }()
    
    lazy var tabIcon2: UIImageView = {
        let img = UIImageView()
        img.image = UIImage(named: "tab2")
        img.frame = CGRect(x: 82, y: 4, width: 29, height: 29)
        img.contentMode = .scaleAspectFit
        return img
    }()
    
    lazy var tabIcon3: UIImageView = {
        let img = UIImageView()
        img.image = UIImage(named: "tab3")
        img.frame = CGRect(x: screen.width / 2 + 48, y: 4, width: 29, height: 29)
        img.contentMode = .scaleAspectFit
        return img
    }()
    
    lazy var tabIcon4: UIImageView = {
        let img = UIImageView()
        img.image = UIImage(named: "tab4")
        img.frame = CGRect(x: screen.width / 2 + 110, y: 4, width: 29, height: 29)
        img.contentMode = .scaleAspectFit
        return img
    }()
    
    @objc func logout() {
        dismiss(animated: true, completion: nil)
    }
}
